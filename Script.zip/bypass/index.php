<?php 

require 'config.php';
require 'settings.php';
?>
  
  
    <!DOCTYPE html>
    <html lang="en">

    <head>
        
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="MVPAlam">
        <!-- set a header -->
        <!-- Get Tittle From settings.php -->
        <title><?php echo $title ?></title>
        <!-- Get Tittle From settings.php -->
        <link href="//v4-alpha.getbootstrap.com/examples/narrow-jumbotron/narrow-jumbotron.css" rel="stylesheet">
        <link rel="icon" type="image/png" href="<?php echo $icon ?>" sizes="32x32">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <!-- change image url to your image url -->
        <style>html {background-color:#ababab;display:flex;align-items:center;justify-content:center;background-image:url(../bypass/image/preview.jpg);background-repeat:no-repeat;background-size:auto;height:100%;}
        .header{text-align:center;}
        </style>
        <!-- change image url to your image url -->
        <!-- set a header -->
    </head>

    <body>

        <div class="container">
            <div class="header clearfix">
                <!-- Get Tittle From settings.php -->
                <h3 class="text-muted"><?php echo $title ?></h3>
                <!-- Get Tittle From settings.php -->
            </div>
            <h2 class="text-center">Bypass Generator</h2>
            <div class="row">
                <div class="col-md-12 form-group">
                    <input type="text" class="form-control url" placeholder="Masukan ID File Google Drive Yang Limit">
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 form-group">
                    <button id="submit" type="submit" class="btn btn-success btn-block"> Generate Bypass</button>
                </div>
            </div>
            <div class="ajax-result">
                <div class="progress loader mb-4">
                    <div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width:100%">Loading........</div>
                </div>
                <div id="report" class="mb-4"></div>
            </div>
            <footer class="footer">
                <p>&copy; <?php echo $title ?> 2019</p>
            </footer>
        </div>
        <!-- set a generator ouput -->
        <script>
            $(document).ready(function() {
                $(".loader").hide();
                $("#report").hide();
                $("#submit").click(function(event) {
                    var url = $('.url').val();
                    $(".loader").show();
                    $.ajax({
                        type: "POST",
                        url: '<?php echo $domain;?>/generate.php',
                        data: {
                            url: url,
                        },
                        success: function(data) {
                            $("#report").show();
                            $('#report').html(data);
                            $(".loader").hide();
                        }
                    });
                });
            });
        </script>
        <!-- set a generator ouput -->
    </body>

    </html>