<?php
require 'config.php'; //Menghubungkan Dengan File Config.php
$url=$_POST['url']; //Untuk Mendapatkan URL
$encrypted = my_simple_crypt($url); //Mengencode URL Yang Dimasukan
//Output generator link
echo '<h2 class="text-center">Link Download Hasil Bypass</h2>';
echo '<input type="text" class="form-control" value="https://drive.mydriveku.com/file/'.$encrypted.'">';
//Output generator link
?>