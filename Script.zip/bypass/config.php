<?php
require 'encrypt.php'; //Untuk Menghubungkan Dengan File Encrypt.php
$domain='https://nddrive.xyz/bypass'; //Masukan Domain Dengan Http/Httpsnya Di antara tanda kutip
