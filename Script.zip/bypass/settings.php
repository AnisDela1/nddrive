<?php

$title = 'Bypass Google Drive By NDDrive'; //Masukan Judul Halaman ByPass
$icon = "https://nddrive.pw/wp-content/uploads/2021/07/NDDrive-1.png"; //Masukan URL ICON Website Google Sharer Anda