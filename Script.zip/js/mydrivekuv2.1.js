function delete_infobro(e) {
    var a = "t" + e;
    $.ajax({
        url: "/ajax.php?ajax=delete",
        type: "POST",
        dataType: "json",
        data: "id=" + e,
        success: function(e) {
            "200" == e.code ? (alert("file deleted !"), document.getElementById(a).style.display = "none") : swal("Code : " + e.code, "Message : " + e.file, "error")
        },
        error: function(e, a, t) {
            alert("Status: " + a + "\n" + t)
        }
    })
}

function get_info(e) {
    var a = e;
    document.getElementById("masukkanId").value = a, $.ajax({
        url: "/ajax.php?ajax=info",
        type: "GET",
        dataType: "json",
        data: "id=" + a,
        success: function(e) {
            document.getElementById("masukkanNama").value = e.nama, document.getElementById("masukkanSubtitle").value = e.subtitle
        }
    }), $("#modalForm").modal("show")
}

function delete_info(e) {
    var a = "t" + e;
    $.ajax({
        url: "/ajax.php?ajax=delete",
        type: "POST",
        dataType: "json",
        data: "id=" + e,
        success: function(e) {
            "200" == e.code ? (swal("file deleted !"), document.getElementById(a).style.display = "none") : swal("Code : " + e.code, "Message : " + e.file, "error")
        },
        error: function(e, a, t) {
            alert("Status: " + a + "\n" + t)
        }
    })
}



function get_ace(e) {
    var a = e;
    document.getElementById(a).disabled = !0, document.getElementById(a).innerHTML = "Uploading..", $.ajax({
        url: "/ajax.php?ajax=mirrorace",
        type: "GET",
        dataType: "json",
        data: "id=" + a,
        success: function(e) {
            "200" == e.code ? swal("Success! Refresh", "result : " + e.file, "success") : swal("Code : " + e.code, "Message : " + e.file, "error")
        },
        error: function(e, a, t) {
            alert("Status: " + a + "\n" + t)
        }
    })
}

function get_multi(e) {
    var a = e;
    document.getElementById(a).disabled = !0, document.getElementById(a).innerHTML = "Uploading..", $.ajax({
        url: "/ajax.php?ajax=multiup",
        type: "GET",
        dataType: "json",
        data: "id=" + a,
        success: function(e) {
            "200" == e.code ? swal("Success! Refresh", "result : " + e.file, "success") : swal("Code : " + e.code, "Message : " + e.file, "error")
        },
        error: function(e, a, t) {
            alert("Status: " + a + "\n" + t)
        }
    })
}

function get_vid(e) {
    var a = e;
    document.getElementById(a).disabled = !0, document.getElementById(a).innerHTML = "Uploading..", $.ajax({
        url: "/ajax.php?ajax=vidcloud",
        type: "GET",
        dataType: "json",
        data: "id=" + a,
        success: function(e) {
            "200" == e.code ? swal("Success!", "Track ID : " + e.file, "success") : swal("Code : " + e.code, "Message : " + e.file, "error")
        },
        error: function(e, a, t) {
            alert("Status: " + a + "\n" + t)
        }
    })
}

function kirimProfilForm() {
    var e = $("#masukNama").val();
    if ("" == e.trim()) return alert("Enter name !"), $("#masukNama").focus(), !1;
    $.ajax({
        url: "/ajax.php?ajax=profile",
        type: "POST",
        dataType: "json",
        data: "id=" + e,
        success: function(e) {
            "200" == e.code ? (swal("Success !"), location.reload()) : swal("Code : " + e.code, "Message : " + e.name, "error")
        },
        error: function(e, a, t) {
            alert("Status: " + a + "\n" + t)
        }
    })
}

function kirimSettingForm() {
    var e = $("#domain").val(),
        a = $("#title").val(),
        t = $("#player").val(),
        r = $("#tag").val(),
        o = $("#description").val(),
        s = $("#copyright").val(),
        n = $("#webmaster").val(),
        l = $("#clientid").val(),
        i = $("#secret").val(),
        c = $("#redirect").val();
        w = $("#webset").val();
        z = $("#analytics").val();
    if ("" == e.trim()) return alert("Enter Domain !"), $("#domain").focus(), !1;
    $.ajax({
        url: "/ajax.php?ajax=setting",
        type: "POST",
        dataType: "json",
        data: "domain=" + e + "&title=" + a + "&player=" + t + "&tag=" + r + "&description=" + o + "&copyright=" + s + "&webmaster=" + n + "&clientid=" + l + "&secret=" + i + "&redirect=" + c + "&webset=" + w + "&analytics=" + z,
        success: function(e) {
            "200" == e.code ? (swal("Success !"), location.reload()) : swal("Code : " + e.code, "Message : " + e.file, "error")
        },
        error: function(e, a, t) {
            alert("Status: " + a + "\n" + t)
        }
    })
}

function kirimMirrorForm() {
    var e = $("#multiu").val(),
        a = $("#multik").val(),
        t = $("#vidu").val(),
        r = $("#vidk").val(),
        o = $("#aceu").val(),
        s = $("#acek").val(),
        n = $("#mir1").val(),
        l = $("#mir2").val(),
        i = $("#mir3").val(),
        c = $("#mir4").val(),
        u = $("#mir5").val();
        w = $("#multiset").val();
        z = $("#aceset").val();
        b = $("#vidset").val();
    $.ajax({
        url: "/ajax.php?ajax=mirror",
        type: "POST",
        dataType: "json",
        data: "mirroruser=" + e + "&mirrorpass=" + a + "&viduser=" + t + "&vidkey=" + r + "&aceuser=" + o + "&acekey=" + s + "&mir1=" + n + "&mir2=" + l + "&mir3=" + i + "&mir4=" + c + "&mir5=" + u + "&multiset=" + w + "&aceset=" + z + "&vidset=" + b,
        success: function(e) {
            "200" == e.code ? (swal("Success !"), location.reload()) : swal("Code : " + e.code, "Message : " + e.file, "error")
        },
        error: function(e, a, t) {
            alert("Status: " + a + "\n" + t)
        }
    })
}

function kirimAdsForm() {
    var e = $("#banner1").val(),
        a = $("#banner2").val(),
        t = $("#jw").val();
    $.ajax({
        url: "/ajax.php?ajax=ads",
        type: "POST",
        dataType: "json",
        data: "banner1=" + escape(e) + "&banner2=" + escape(a) + "&jw=" + escape(t),
        success: function(e) {
            "200" == e.code ? (swal("Success !"), location.reload()) : swal("Code : " + e.code, "Message : " + e.file, "error")
        },
        error: function(e, a, t) {
            alert("Status: " + a + "\n" + t)
        }
    })
}

function cobaHapus(e) {
    var a = "a" + e;
    $.ajax({
        url: "/ajax.php?ajax=delkun",
        type: "POST",
        dataType: "json",
        data: "id=" + e,
        success: function(e) {
            swal(e.message), document.getElementById(a).style.display = "none"
        }
    })
}

function cobaDapet(e) {
    var a = e;
    $.ajax({
        url: "/ajax.php?ajax=role",
        type: "GET",
        dataType: "json",
        data: "id=" + a,
        success: function(e) {
            document.getElementById("masukkanEm").value = e.email, document.getElementById("masukkanRole").value = e.role
        }
    }), $("#modalForm").modal("show")
}

function kirimRoleForm() {
    var e = $("#masukkanEm").val(),
        a = $("#masukkanRole").val();
    if ("" == a.trim()) return alert("Enter Role !"), $("#masukkanRole").focus(), !1;
    $.ajax({
        url: "/ajax.php?ajax=role-post",
        type: "POST",
        dataType: "json",
        data: "id=" + e + "&role=" + a,
        success: function(e) {
            "200" == e.code ? (swal("Success !"), location.reload()) : swal("Code : " + e.code, "Message : " + e.role, "error")
        },
        error: function(e, a, t) {
            alert("Status: " + a + "\n" + t)
        }
    })
}

function myDownload() {
    var id = document.getElementById("down-id").innerHTML;
    document.getElementById("down").innerHTML = '<i class="fa fa-spinner"></i>  Downloading';
    document.getElementById("down").disabled = !0;
    var loadingTimeout = window.setTimeout(function() {
        document.getElementById("down").innerHTML = '<i class="fa fa-spinner"></i> Still loading..'
    }, 6000);
    $.ajax({
        url: '/ajax.php?ajax=download',
        type: 'POST',
        dataType: 'json',
        data: 'id=' + id,
        success: function(data) {
            if (data.code == "200") {
                window.clearTimeout(loadingTimeout);
                window.location.href = data.file
            } else {
                swal("Code : " + data.code, "Message : " + data.file, "error")
            }
        },
        error: function(xhr, status, msg) {
            alert('Status: ' + status + "\n" + msg)
        }
    })
}

function copy(that) {
    var inp = document.createElement('input');
    document.body.appendChild(inp)
    inp.value = that.textContent
    inp.select();
    document.execCommand('copy', !1);
    inp.remove();
    swal("Text Copied!")
}