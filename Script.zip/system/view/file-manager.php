<?php if($user['role'] == "admin"):?>
<!-- Begin Page Content -->
<script type="text/javascript" src="js/table-admin.js"></script>
<div class="container-fluid">
   <div class="d-sm-flex align-items-center justify-content-between mb-4">
      <h1 class="h3 mb-0 text-gray-800">File Manager</h1>
   </div>
   <div class="row">
      <div class="col-xl-12 col-md-12 mb-4">
         <div class="card shadow mb-4">
            <div class="card-body">
               <div class="form-group" style="padding:0 0 15px">
                  <div class="input-group">
                     <input class="form-control form-control-sm" type="text" id="gopage" class="form-control form-control-sm" placeholder="Go to page...">
                     <span class="input-group-btn">
                     <button class="btn btn-primary btn-sm halamanw" > Go!</button>
                     </span>
                  </div>
               </div>
               <div id="data"></div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php endif;?>