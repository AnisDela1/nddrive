<?php 
defined("BASEPATH") or exit("No direct access allowed");
if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest')):?>
<?php
error_reporting(0);
if ($_FILES['file_input']) {
$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$namaFile = 'sub-'.substr(str_shuffle($permitted_chars), 0, 16).'.srt';
$namaFile2 = $_FILES['file_input']['name'];
$namaSementara = $_FILES['file_input']['tmp_name'];
$extensi = pathinfo($namaFile2, PATHINFO_EXTENSION);

// tentukan lokasi file akan dipindahkan
$dirUpload = "subtitle/";
if ($extensi=="srt") {
$terupload = move_uploaded_file($namaSementara, $dirUpload.$namaFile);
if ($terupload) {
echo "$namaFile";
}
} else {
    echo"Failed not SRT file !!";
}

}

?>
<?php endif;?>